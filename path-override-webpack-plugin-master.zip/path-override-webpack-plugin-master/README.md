# path-override-webpack-plugin

Based originally on

[https://github.com/jamiehill/path-override-webpack-plugin]

Extended to support context exclusion via regular expressions.

Reduced to a sole TypeScript file to be used directly in projects.

_This *NOT* an npm module any longer!_
